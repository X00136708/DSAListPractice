#include "NodeOfEmployee.h"



NodeOfEmployee::NodeOfEmployee()
{
}
NodeOfEmployee::NodeOfEmployee(Employee e) {
	emp = e;
}

NodeOfEmployee::~NodeOfEmployee()
{
}
