#include "Employee.h"



Employee::Employee()
{}

Employee::Employee(string n, double s) {
	name = n;
	salary = s;
}
Employee::Employee(const Employee& e) {
	name = e.name;
	salary = e.salary;

}

ostream& operator<<(ostream& output, const Employee& e) {
	output << "Employee name: " << e.name << " with a salary of: " << e.salary << endl;
	return output;
}

Employee::~Employee()
{}
