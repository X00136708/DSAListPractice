#include "ListOfEmployee.h"
#include "Employee.h"
#include "NodeOfEmployee.h"
#include <iostream>
using namespace std;



ListOfEmployee::ListOfEmployee()
{
}



ListOfEmployee::~ListOfEmployee()
{
}

void ListOfEmployee::insertAtFront(string name, double salary) {
	NodeOfEmployee *emp = new NodeOfEmployee(Employee(name, salary));
	NodeOfEmployee *temp = head;
	head = emp;
	emp->next = temp;
}

void ListOfEmployee::printList() {
	NodeOfEmployee* emp = head;
	while (emp != NULL) {
		cout << emp->emp << endl;
		emp = emp->next;
	}
}

