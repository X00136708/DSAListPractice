#include <iostream>
#include "Employee.h"
#include "ListOfEmployee.h"
#include "NodeOfEmployee.h"
using namespace std;

int main() {
	ListOfEmployee e;
	e.insertAtFront("Jeffrey", 40000);
	e.printList();
}