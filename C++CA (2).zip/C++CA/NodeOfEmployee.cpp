#include "NodeOfEmployee.h"



NodeOfEmployee::NodeOfEmployee()
{
}
NodeOfEmployee::NodeOfEmployee(Employee e) {
	empData = e;
}

NodeOfEmployee::~NodeOfEmployee()
{
}
